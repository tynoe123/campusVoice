import { GoogleGenAI, Type } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });

export interface Report {
  id: string;
  category: string;
  description: string;
}

export interface Cluster {
  id: string;
  title: string;
  description: string;
}

export async function clusterReports(reports: Report[], existingClusters: Cluster[]) {
  const prompt = `
    You are an AI analyst for a university complaint system. 
    Your task is to analyze individual student reports and group matching issues into "Issue Clusters".
    
    EXISTING CLUSTERS:
    ${existingClusters.map(c => `- [ID: ${c.id}] ${c.title}: ${c.description}`).join('\n')}
    
    NEW REPORTS TO ANALYZE:
    ${reports.map(r => `- [ID: ${r.id}] Category: ${r.category}, Description: ${r.description}`).join('\n')}
    
    Instructions:
    1. For each new report, check if it fits into an EXISTING CLUSTER.
    2. If a report is UNIQUE, suggest a NEW CLUSTER (Title and Description).
    3. Return a JSON object mapping report IDs to cluster IDs.
    
    Output Format (JSON):
    {
      "assignments": [
        { "reportId": "uuid", "clusterId": "existing-id" },
        { "reportId": "uuid", "newCluster": { "title": "Main Library Wi-Fi Issues", "description": "Multiple students reporting unstable internet in the central library." } }
      ]
    }
  `;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            assignments: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  reportId: { type: Type.STRING },
                  clusterId: { type: Type.STRING, description: "Existing cluster ID" },
                  newCluster: {
                    type: Type.OBJECT,
                    properties: {
                      title: { type: Type.STRING },
                      description: { type: Type.STRING }
                    },
                    required: ["title", "description"]
                  }
                },
                required: ["reportId"]
              }
            }
          },
          required: ["assignments"]
        }
      }
    });

    return JSON.parse(response.text);
  } catch (error) {
    console.error("Gemini clustering failed:", error);
    return null;
  }
}

export async function autoCategorize(description: string) {
  const prompt = `Categorize the following university report into one of these: Academic, Facilities, Safety, Governance, Health, Other.
  Report: "${description}"
  Return only the category name.`;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: prompt,
    });
    return response.text.trim();
  } catch (error) {
    return "Other";
  }
}
